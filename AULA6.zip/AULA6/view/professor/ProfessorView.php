<?php $professores = $_REQUEST["professores"]; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Meu site</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll"
                aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarScroll">
                <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/<?php echo FOLDER; ?>/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                            href="/<?php echo FOLDER; ?>/?controller=Estudante&acao=listar">Estudantes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                            href="/<?php echo FOLDER; ?>/?controller=Professor&acao=listar">Professores</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="text-center">
            <h2>Semana da acessibilidade</h2>
        </div>
    </div>

    <div class="row justify-content-center">
        <img src="https://www.ufes.br/sites/default/files/field/image/simbolos-acessibilidade-educacional.jpg"
            alt="Representação gráfica de como utilizar a tag alt em uma imagem para pessoas com deficiência visual."
            style="width: 20%;">
    </div>

    <br>
    <div class="text-center"><a href="/aula3/?controller=Professor&acao=salvar" class="btn btn-success">Cadastrar novo
            Professor</a>
    </div>

    <br>
    <div class="container">
        <table class="table table-dark">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Idade</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($professores as $professorAtual) { ?>
                    <tr>
                        <td>
                            <?php echo $professorAtual["id"]; ?>
                        </td>
                        <td>
                            <?php echo $professorAtual["nome"]; ?>
                        </td>
                        <td>
                            <?php echo $professorAtual["idade"]; ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

</html>